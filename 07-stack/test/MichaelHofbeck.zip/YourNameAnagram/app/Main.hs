--Michael Hofbeck
module Main where

import Anagram

main :: IO ()
main = do
    input1 <- getLine
    input2 <- getLine
    let result = if (isAnagram input1 input2) then "They are anagrams!" else "These are not anagrams!"
    print result