module Anagram where

import Data.List as D

isAnagram :: String -> String -> Bool
isAnagram  xs ys = (D.sort (xs) == D.sort (ys))