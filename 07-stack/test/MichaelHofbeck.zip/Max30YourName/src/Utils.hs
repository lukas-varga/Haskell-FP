module Utils where

import qualified Data.Text as T

max30Chars :: String -> Bool
max30Chars xs = (T.length (T.strip (T.pack (xs))) <= 30)