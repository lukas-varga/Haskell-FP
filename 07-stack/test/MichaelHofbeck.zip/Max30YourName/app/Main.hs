--Michael Hofbeck
module Main where

import Utils

main :: IO ()
main = do
    input <- getLine
    let result = if (max30Chars input) then "this string is valid" else "this string is invalid"
    print result