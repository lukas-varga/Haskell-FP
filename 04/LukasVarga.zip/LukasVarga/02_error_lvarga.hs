-- Name: Lukas Varga

-- Fix the error in the code below. Load the file, read the error message

-- and fix ONE ERROR at a time. Then load the file and read the next error

-- message. 

-- Note if either a change in the type of a function / value or  the value/definition will allow 

-- the code to compile, you can change either to make it error-free. 

-- Hint comment out all but the code you are currently working on. Leave all code uncommented before submission. 

--Load your completed code in the answer section

a1:: Int

a1 = 17                   



a2 =  4          





a3 :: String

a3 = "Hello"                    

 

a4 = if 'e' == 'g' then 4

     else 5        



a5 :: Double

a5 = 77.4



a6:: Int -> Int

a6 x = x `div` 2



a7:: Int -> Int

a7 x = x * 7



a8 = True && False               



a9 :: Integer -> String

a9 x = "Hello"



a10 = "Goodbye"