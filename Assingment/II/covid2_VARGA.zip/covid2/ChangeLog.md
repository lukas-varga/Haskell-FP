# Changelog for covid2

## Unreleased changes
